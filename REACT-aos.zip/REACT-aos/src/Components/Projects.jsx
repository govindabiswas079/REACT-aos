import Me from './img/projects/appleclone.png';
import PrimeAnim from './img/projects/prime-animation.png';

const Projects=[
    {
        name:"Apple Clone",
        tech:"HTML CSS Javascript",
        link: "https://fidalmathew.github.io/apple.com/",
        code:"https://github.com/FidalMathew/apple.com",
        img:Me
    }
    ,{
        name:"Amazon-Prime Hover",
        tech:"HTML CSS ",
        link: "https://fidalmathew.github.io/amazonprime-movieanimation/",
        code:"https://github.com/FidalMathew/amazonprime-movieanimation",
        img:PrimeAnim
    }
    ,{  name:"Apple Clone",
        tech:"HTML CSS Javascript",
        link: "https://fidalmathew.github.io/apple.com/",
        code:"https://github.com/FidalMathew/apple.com",
        
        img:Me
    }
    ,{
        name:"Apple Clone",
        tech:"HTML CSS Javascript",
        link: "https://fidalmathew.github.io/apple.com/",
        code:"https://github.com/FidalMathew/apple.com",
        img:Me
    }
    ,{
        name:"Apple Clone",
        tech:"HTML CSS Javascript",
        link: "https://fidalmathew.github.io/apple.com/",
        code:"https://github.com/FidalMathew/apple.com",
        img:Me
    }
    ,{
        name:"Amazon-Prime Hover",
        tech:"HTML CSS ",
        link: "https://fidalmathew.github.io/amazonprime-movieanimation/",
        code:"https://github.com/FidalMathew/amazonprime-movieanimation",
        img:PrimeAnim
    }
];

export default Projects;